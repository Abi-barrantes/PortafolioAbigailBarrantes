package Tienda_Abi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tienda_AbiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tienda_AbiApplication.class, args);
	}

}
