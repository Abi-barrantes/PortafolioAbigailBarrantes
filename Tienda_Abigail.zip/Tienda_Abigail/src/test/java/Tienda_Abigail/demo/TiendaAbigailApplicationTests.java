package Tienda_Abigail.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaAbigailApplicationTests {

	@Test
	void contextLoads() {
	}

}
